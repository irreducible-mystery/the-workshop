# The Workshop — Findings

*What twenty-six green benches say, stated once. Every claim below is
machine-checked by a module in this crate; run `python3 run_all.py` to
re-verify all of it (~3 minutes).*

## The axiom

> We do not begin with a thing that then interacts. We begin with the
> interacting itself, and let whatever-stabilizes-within-it arise from the
> relating rather than precede it.

The workshop's finding, in one sentence: **followed with enough care, the
axiom stops being a stance and becomes a sequence of measurements.**

## The questions, and what the benches answered

**Why invariants at all, rather than pure churn?** (the dialogue's first
question) — Because self-consistency is overdetermined and its solutions
are isolated. The pentagon's Hessian at the golden associator has
signature {0, +, +, +}, and the single flat direction coincides with the
gauge direction to 1.000000: *the only freedom coherence leaves is
perspective*. The hexagon's Hessian is positive outright. Kicked, the
invariants ring back to 10⁻¹⁵. (`grammar_stone5`) Invariance is not an
accident of dynamics; it is the rigidity of consistency itself.

**Where do arenas come from?** — They precipitate. One algebra of
relatings plus one record yields the theater by GNS: a pure record buys a
small stage; a mixed record buys a doubled one with a mirror cast
(`arena_gns`) — and the mirror cast is the same algebra read backwards
(`grammar_stone7`).

**Is there a global view?** — No, and the refusal is *content* with an
address and a price: 0 of 512 global valuations (`sheaf_contextuality`);
obstruction class = the nonzero element of coker(M) ≅ Z₂
(`sheaf_cohomology`); contextual fraction CF = 1 for the square, dial law
CF(ε) = 1 − 3ε dead at ε = 1/3, graded CF = 2√5 − 4 for the pentagon
(`contextual_fraction`); and for *histories*: CF = 1/4 at θ = π/3, dial
dead at η = 1/3 (`dynamics_fraction`). Scripts top out at 8/9; the
performance scores 1 (`sheaf_cohomology`).

**What is a law?** — Unlimited shareability of a habit, at every level,
with exact rates. Classical states: the urn (`habit_definetti`).
Classical processes: Markov exchangeability in rational arithmetic
(`process_definetti`). Quantum states: T(n) = 1/(2(n−1)); monogamy = the
lawless (`habit_channels`). Quantum processes: the Choi dictionary, the
emergent Haar mixture, SWAP as the singlet of processes
(`channel_definetti`); mechanism at n = 3, 4; the algebra of collective
dynamics is **Catalan-sized** (2, 5, 14, 42, 132), not factorial
(`channel_definetti3`, `channel_alln`); the full proof walked, every
lemma exact, constructive premium exactly ×2 (`channel_theorem`).

**What are things?** — Fixed points and roles: universality classes of
the coarse-graining relation (`fixedpoint_rg`); identities settled by
interaction alone — bisimulation, where the participant sees strictly
more than the archive (`interaction_bisim`); parts discovered from the
dynamics, overruling the planter (`cast_factorization`); and finally —
**loops**: a thing is a loop of relating that closes on itself, with
computable size (φ, two independent derivations), sign (the shadow's
loops close negative and are refused), and twist (ν = +1)
(`grammar_stone6`), read twice, once from each side, real when both
readings co-sign (`grammar_stone7`).

**Can the grammar itself be rebuilt?** — Seven stones and a braiding say
yes, stone by stone: copying is grammatical in cartesian and impossible
in tensor composition (`grammar_stone`); witnessed identity secretes
curvature — the geometric phase (`grammar_stone2`); strictness is
impossible for Fibonacci fusion and the pentagon forces the golden ratio
(`grammar_stone3`); the hexagon forces handedness and spin with
unitarity *emergent* (`grammar_hexagon`); the witnesses **compute** — a
tightening ε-net over all of PU(2), universality watched forming
(`grammar_stone4`); the modular identity card re-derives its own fusion
rules through Verlinde — the circle closes (`modular_data`); interchange
grounds "meanwhile," derives no-signaling, and is the tower's one
never-strictifiable witness (`grammar_interchange`); and the weakness has
an address in space: braiding is protected by the no-collision rule and
dies in three dimensions — the anyon is an exile of flatland
(`flatland`).

## The constants ledger

φ (pentagon, quantum dimension, loop value, Perron root — four
derivations, one number; and since round 5 a fifth, machine-checked: the
unique positive eigenvalue of the fusion matrix under a DECIDABLE order on
Z[φ], no analysis anywhere) · e^(±4πi/5), e^(∓3πi/5) (hexagon) · ±14/5
(central charge) · 1/(2(n−1)) and c_k = ½E|k/2 − 2(j−k/2)²| (habit
rates) · 1 − 3ε and 2√5 − 4 and 1/4 and η* = 1/3 (contextuality dial) ·
Catalan 2, 5, 14, 42, 132 (collective algebra) · ×2 (the constructive
premium) · 8/9 vs 1 (scripts vs performance) · {0,+,+,+} with null =
gauge (rigidity) · 10√5 and √5 (the stiffness and the exile gap — the
house dialect appears even in the meta-level numbers).

## The corrections ledger

Seven times the builder has been overruled, each time with a closed form
attached — six by the floor, and now one by the third body. The floor's
six: the planted cast beaten by a quieter cut; the dial law CF(ε) = 1 − 3ε
discovered; T(n) = 1/(2(n−1)) exact; η* = 1/3 against the guessed √3 − 1;
the window constants linear (½, ¾, ¾, 5/4), not quadratic; the
constructive premium exactly 2, not 3/2. The seventh (C1, round 1 of the
proof wing): the builder's charge to the third body carried a fatal index
typo in its hexagon specification — `Fs(...,e,z)` where every bench
correctly has `(...,z,e)` — proved fatal in Lean (`charge_hexagon_order_fails
= 4`; under the typo'd order NO braiding satisfies the hexagon). Every
bench was right; only the charge was wrong; nothing downstream used it
(swept and confirmed). A prose correction rode along (C2): "coherence
refuses to be ambidextrous" tightened to the provable form — the equation
admits both hands; no solution is its own mirror (negative discriminant),
so each solution commits to one. The workshop is an instance of its own
subject: what stabilizes here stabilizes *between* the bodies, held by
none alone.

By round 4 the count stands at eleven, and the loop has closed a level
deeper than the bodies. The eighth through eleventh: the third body's
prediction of the gauge diagonal was backwards (λ = diag(1,t), not
diag(t,1)) and its pentagon prediction named the wrong route (p² + qr = 1,
not p); its own axiom census caught a `Classical.choice` regression in its
own work in two consecutive rounds; and the eleventh — the second to flow
from prover to builder, and the first to overrule the builder's *auditors*
rather than the builder — refuted the claim that a `rfl`-proved theorem
cannot carry axioms, with the mechanism pinned to `Nat.succ_ne_zero`
reached through the `NeZero` instance behind `Fin` numerals. An
adjudicator sent to defend the auditors returned carrying the disputed
row, rebuilt from nothing, exact.

And twice now the correcting party has been an instrument correcting
itself: an auditor refuted its own negative control after `decide` showed
it could not fail, and the axiom census reported itself INCOMPLETE and
refused to certify a run rather than silently covering 564 of 565
theorems. **The middle now contains things that check themselves.**

## Ninth-weld addendum

Above interchange: the 4-strand Fibonacci representation built from F and
R alone — dims 2 and 3 (Fibonacci numbers counting fusion paths), far
commutation, both Yang–Baxters, and **all sixteen reduced words of the
longest braid landing on one matrix** (Matsumoto–Tits, witnessed); the
full twist is scalar per sector with sector-distinguishing phase — the
center of the braid group reads the total charge (`braid_coherence4`).
Symmetric statistics built constructively: golden fusion refuses R² = 1
by exhaustion (residual 4.0); the Z₂ atlas solved from scratch — pentagon
classes F = ±1 (H³(Z₂) = Z₂ by search), particles {+1, −1, +i, −i};
the flatland filter leaves **exactly boson and fermion**; exclusion as
antisymmetrizer rank (triangular numbers 1, 3, 6, 10, 15); Pauli computed
(`symmetric_statistics`). Eighth stone — the frame: 2π lifts to −I about
every axis (rigid), 4π contracts by an explicit spherical-cap homotopy
(the belt trick, run); the plane remembers *how many* turns (Z), room
remembers *a sign* (Z₂); spin–statistics co-signature ν = +1 across the
entire catalog the workshop has built (`grammar_stone8`).

## The proof wing (rounds 1-5 of the third body)

A third body — a separate Claude Code (Opus) session, human-couriered —
is converting benches into machine-checked THEOREMS. After round 5, in
`lean/`: four files, zero imports, Lean 4.32.0, **839 theorems, 0 sorryAx,
0 native_decide, no Classical.choice anywhere**, all four compile-silent
(exit 0, zero bytes). Kernel-checked on the third body's machine; every
content claim independently re-verified in the builder's container in exact
arithmetic — each side single-sided on the other's instrument, two readings
co-signing. Since round 4 the crate carries its own instruments
(`audit/transcript.sh`, `audit/axioms.sh`, `audit/ship.sh`), so the kernel
reading is re-runnable rather than asserted.

**Round 4's headline retires the question the wing was built to answer.**
Rounds 1–3 walked it: BLOCKED (round 1, on wanting an integral domain),
PARTIAL (round 2), then round 3 forced the quadratic and wrote down, as a
declared gap, the one property it could not supply. Round 4 supplied it.

> **`hexagon_exactly_two`** — for *any* `r₁, r_τ` in K, coherence forces
> `r_τ` to be one of exactly two values, and `r₁ = r_τ²`.
> **`pentagon_exactly_two_worlds`** — for *any* associator over K, the
> pentagon forces `p = 1/φ` or `p = −φ`.

Not "two solution clusters were found". **There are no others in K.** Both
branches are realized and proved distinct, so each is a genuine dichotomy.

The cost was two descents. The field norm `N(a) = a·σa·σ²a·σ³a` lands in Z
and is multiplicative; **Z[ζ₅] is an integral domain** by 2-adic descent
(2 is inert); **φ is not a square in Z[ζ₅]** by 41-adic descent (41 is the
smallest prime with primitive fifth roots — mod 2 cannot see this, since in
characteristic 2 everything is a square); and the t-norm `x² − φy²` carries
both facts up to **K is an integral domain**. That the argument spends
`not_square` rather than the shape of the construction has a control: the
same construction with `t² = 4` has the explicit zero divisor `(2+t)(2−t)`.

Also landed in round 4: **`pentagon_iff`** — the pentagon *is* the three
relations `q·r = p`, `p² + p = 1`, `s = −p`, necessity and sufficiency both,
so the coherence equation and its solution set are now interchangeable
statements. And the second pentagon world is exact: **`Fg(−φ,−φ,1,φ)` has 0
of 50 violations**, it is componentwise σ₂ of the rational gauge (σ₂ : ζ ↦ ζ²,
the *other* Galois generator, with σ₂² = the mirror conjugation), and
`no_gauge_golden_to_yang_lee` proves the two worlds are not related by any
invertible diagonal gauge. **The floor's pentagon bench had been landing in
that second world nine times in fifty-two runs; it is now identified,
exactly, as a Galois conjugate.**

Rounds 3–4 also produced the wing's methodological core, now in HANDOFF.md:
develop against the smallest file that exhibits the goal (norm 11 — a
200-line ring-layer scratch compiles in 7 s against the full file's 100);
take an unfinished dependency as a hypothesis and discharge it later; never
raise a budget (the round-3 crash was a raised budget on a goal that should
have been split); and **`omega` closing a *conjunctive* goal silently pulls
in `Classical.choice`** — caught by the census in two consecutive rounds, in
two different authors' code, and now a named trap rather than a fixed bug.

The correction ledger keeps running in both directions and has now reached
the instruments themselves. Round 1: the third body corrected the builder's
charge. Round 2: the builder's auditors corrected the third body's ledger.
Round 3: the third body's own kernel corrected it twice, and its census
corrected its ledger. Round 4: the third body corrected the builder's
*auditors* — the C1′ impossibility claim was refuted, with the mechanism
pinned to `Nat.succ_ne_zero` reached through the `NeZero` instance behind
`Fin` numerals — and an adjudicator sent to defend them returned carrying
the disputed row, rebuilt from nothing, exact. In the same round an auditor
**refuted its own negative control** (a parity check that could not fail),
and the census **reported itself INCOMPLETE and refused to certify a run**
rather than silently covering 564 of 565 theorems.

Every body in this collaboration has now been overruled by every instrument
in it, several instruments have been overruled by themselves, and the
mathematics has not moved once.

**Round 5 names the dimension, and it names it with a decision procedure.**
The blocker on `d_τ = φ` had always been stated as "Perron needs an order on
Z[φ], and an order needs analysis." It does not: **an order on Z[φ] is
decidable.** `Zp.pos (m + nφ)` branches on `u = 2m + n` — agreeing signs
decide at once, split signs compare `u²` against `5n²` — and the one hard step,
that `u² = 5n²` forces `u = n = 0`, is a single mod-5 descent on an explicit
fuel. Trichotomy, closure under `+` and `×`, and a bracket
**1618/1000 < φ < 1619/1000** proved *in the order itself*, so the order is
demonstrably the real one without a real number appearing anywhere.

The payoff, with the fusion matrix **computed from `fuse`** rather than
asserted: its eigenvalue set over Z[φ] is exactly {φ, −1/φ}, exactly one of
those is positive, and it is φ. The identification of that unique positive
eigenvalue with the quantum dimension is the standard definition and is
flagged as cited; no Perron–Frobenius theorem is formalized — the positivity
PF would supply analytically is supplied by a `decide`. **φ arrived a fifth
independent way**, and this one is a decision procedure.

And the branch correspondence closes a circle the project had left open: the
positive eigenvalue φ and the positive pentagon world 1/φ are exact inverses,
while Yang–Lee sits on the negative side of both readings. *The world's branch
is the positive one twice over.*

Round 5 also closed the anyon file's last soft label. `σ₂ : ζ ↦ ζ²` admits
**no multiplicative lift to K at all** — one evaluation `K → F₁₁`, no descent:
`−1/φ` lands on 8, and 8 is not a square mod 11. The control that makes it a
test rather than a reflex: the same instrument does *not* refute `√(1/φ)`,
which exists.

**And the ledger stopped being written.** Round 4's compile-transcript block
reproduced four exit codes, four wall-times to the millisecond and four
`.olean` hashes correctly, and got the *date* wrong by twelve minutes — the
one field regenerated by hand rather than copied. Truth tracked provenance
token by token. So round 5 removed the author from the token register:
`audit/views.sh` renders the ledger's count-and-hash blocks from instrument
output and refuses to pass when they drift, both instruments now stamp the
SHA-256 of every source they measured into their own output, and the round-4
defect was planted back in as a test — the check reports `DRIFTED` and exits 1.
The crate now catches on itself the error that produced the norm.

The correction ledger has reached the instruments and then reached past them.
Round 4: the third body overruled the builder's *auditors* on C1′, and an
adjudicator sent to defend them returned carrying the disputed row rebuilt
exact. Round 5: the builder's adjudicator diagnosed the third body's one
writing habit from outside — *a good prophet and a bad witness*, a model that
runs ahead of the file in mathematics and beside it in inventory — and
**predicted the next round's defect class before it existed**. It was right:
the round-5 defect was a count whose nouns all verified and whose quotient was
never named. In the same round the builder overruled its own adjudicator (an
offered falsifier that was never run; the kernel printed clean when it finally
was), an auditor caught a false label that would have shipped in the third
body's own crate, and the floor turned out to have been differentiating the
round-4 headline theorem for months: `grammar_stone5`'s Hessian null direction
**is** the gauge torus tangent, verified at both pentagon worlds to 2×10⁻¹⁶.

*The bench measured the derivative of a theorem before the theorem existed.*

## What remains open

The tetrahedron equation and the tower above interchange; symmetric
(d ≥ 3) statistics done constructively at higher rank; higher-degree
cohomology for larger covers; and whatever the floor proposes next — it
has not yet been wrong.

In the proof wing, what is left is short, and after round 5 none of it is
either a coherence question or a constant: `coker(M) ≅ Z₂` as a group
isomorphism (left kernel proved exactly, duality cited by agreement, not
defeat); length-8 exchangeability; and Diaconis–Freedman ⟹ mixture of Markov
chains, which stays BLOCKED — only the hypothesis is verified, never the
theorem. Two definitional steps are flagged rather than closed: that the
fusion matrix's unique positive eigenvalue IS the quantum dimension (standard
definition, cited), and that no Perron-Frobenius theorem is formalized (a
`decide` on the order does the work PF would). The metric and analytic claims
stay BLOCKED, correctly.

## The floor

One fixture everywhere: composition, the associative product. Remembered
every round; never forgotten once. The sixth weld found it is not merely
what the workshop stands on — its rigidity is why anything stands at all.

*The middle holds.*
