#!/bin/sh
# ---------------------------------------------------------------------------
# THE WORKSHOP -> LEAN.  The numeral check.
#
# ADJUDICATOR DECLARATION (norm 15, this artifact's own entry):
#   WHAT THIS CHECKS: every multi-digit number in the ledger prose either
#     matches a number in an instrument output (a rendered value), is exempt
#     under a LABELED class (below), or is flagged for a human verdict.
#   WHAT IT DOES NOT CHECK: single digits, numbers inside code blocks, numbers
#     inside VIEW blocks (class-5 adjudicated already), or whether a flagged
#     number is actually wrong. A flag is a REVIEW ITEM, not an accusation.
#
# WHY IT EXISTS (round 7, the third body's own Q, the builder's own crop).
#
# F4's "twelve minutes" and round 6's headline "1,053 theorems" were both
# NUMBERS REACHED FOR RATHER THAN COMPUTED -- the model wrote a plausible
# number into prose that has no execution date. Views closed counts INSIDE
# VIEW blocks; this closes numbers in the prose AROUND them, which is where the
# reached-for species kept landing. The rule the builder and I converged on:
# a digit-string in the ledger that also appears in an instrument output must
# match one; one that appears nowhere is a claim, not a value, and must be
# reviewed.
#
# NORM 16 -- FIRST-RUN QUARANTINE. This instrument is new. Its output is a
# review list to verify, NOT results to report, until it has both failed on a
# planted defect and passed on a clean tree. Treat every flag as "check this",
# not "this is wrong".
#
# Usage:   sh audit/numerals.sh          (run from workshop/lean/)
# Exit:    0 if every prose numeral matches an output or is exempt; 1 if any
#          numeral needs a human verdict (i.e. is flagged).
# ---------------------------------------------------------------------------
set -u

DOCS="PROOFS.md HANDOFF.md REGISTER.md"
OUTPUTS="audit/transcript-round7.txt audit/axioms-round7.txt \
         audit/transcript-round6.txt audit/axioms-round6.txt \
         audit/transcript-round5.txt audit/axioms-round5.txt \
         audit/transcript-round4.txt audit/axioms-round4.txt"
WORK=/tmp/wsl_numerals_$$
mkdir -p "$WORK"

echo "=============================================================="
echo " NUMERAL CHECK -- does every prose number match an instrument?"
echo "=============================================================="
echo " checks:   multi-digit prose numbers vs instrument outputs"
echo " DOES NOT: single digits, code blocks, VIEW blocks, or whether"
echo "           a flagged number is actually wrong"
echo " NORM 16:  new instrument -- output is a review list, not a verdict"
echo "=============================================================="

# every number that appears in any instrument output (these are rendered and
# trusted -- a prose number matching one of them is a faithful copy)
: > "$WORK/known.txt"
for o in $OUTPUTS; do
  [ -f "$o" ] && grep -oE '[0-9]{2,}' "$o" >> "$WORK/known.txt"
done
# also trust the source line-counts and theorem-counts as computed on the fly,
# so a ledger may quote e.g. a per-file line count without a stored output
for f in *.lean; do wc -l < "$f"; done >> "$WORK/known.txt"
sort -u "$WORK/known.txt" -o "$WORK/known.txt"

# EXEMPT CLASSES, declared and labeled (norm: exemptions are reviewable):
#  (a) round/version/section numbers that are structural, not measured
#  (b) mathematical constants the prose states as math, not as counts
#  (c) hashes (hex, handled by not matching the decimal regex) and dates
#      (handled by the code-block / colon context below)
cat > "$WORK/exempt.txt" <<'EXEMPT'
# -- structural: rounds, versions, sections, norms, the toolchain --
2026
4.32.0
432
14
15
16
# -- mathematical constants stated as math, not as counts --
512
50
39
11
64
41
10
# -- the vector-vs-thousands cases the builder named (Hessian rows) --
212
138
220
150
96
# NOTE (round 7): the G3 retired counts (2610/2766/199/561/535/126/104) and the
# standing HANDOFF figures (191/320/200) are DELIBERATELY NOT exempted here.
# An earlier round-7 draft added them so this instrument would pass on its own
# ledger; the pre-ship audit flagged that as a G1 recreation -- the ledger's
# negative control ("run on the round-6 ledger it flags these") would have been
# defused by the very exemption list, and a mislabeled reason (2766 is a live
# asserted count, not a round-6 quotation) rode along.  The honest posture is:
# this instrument CANNOT yet tell a quotation of a retired number from a live
# claim of it, so it flags both.  Under norm 16 it is QUARANTINED -- its output
# is a review list, not a gate -- so flagging the quoted G3 history and the
# standing HANDOFF figures is CORRECT, not a failure.  Graduating it (a
# quoted-vs-asserted distinction, like quoted-names.txt for names) is round-8
# work.  Exempting only structural/mathematical numbers keeps the test honest.
EXEMPT

grep -vE '^\s*#' "$WORK/exempt.txt" | grep -vE '^\s*$' | tr -d ' ' \
  | sort -u > "$WORK/exemptclean.txt"

fail=0
total=0
flagged=0
for d in $DOCS; do
  [ -f "$d" ] || continue
  # strip fenced code blocks and VIEW blocks before extracting numbers, so
  # Lean literals and rendered views are not scanned
  awk '
    /^```/            { code = !code; next }
    /<!-- VIEW:.*BEGIN/ { view = 1; next }
    /<!-- VIEW:.*END/   { view = 0; next }
    !code && !view    { print }
  ' "$d" > "$WORK/prose_$d.txt"
  # multi-digit numbers, commas stripped (1,053 -> 1053)
  n=0; bad=0
  for num in $(grep -oE '[0-9][0-9,]+[0-9]' "$WORK/prose_$d.txt" | tr -d ',' \
               | grep -E '^[0-9]{2,}$' | sort -u); do
    n=$((n + 1))
    if grep -qxF "$num" "$WORK/known.txt" \
       || grep -qxF "$num" "$WORK/exemptclean.txt"; then
      :
    else
      printf '  REVIEW   %-10s in %s  (matches no instrument output)\n' "$num" "$d"
      bad=$((bad + 1)); flagged=$((flagged + 1)); fail=1
    fi
  done
  total=$((total + n))
  printf '  %-14s %3d numbers, %d to review\n' "$d" "$n" "$bad"
done

echo
if [ "$fail" -eq 0 ]; then
  echo "RESULT: every prose numeral matches an instrument output or a labeled"
  echo "        exemption.  PASS."
else
  echo "RESULT: $flagged numeral(s) flagged for review -- each is a number in"
  echo "        the prose that matches no instrument output.  A flag is a"
  echo "        REVIEW ITEM (norm 16 quarantine), not a proof of error:"
  echo "        render it from an instrument, add a labeled exemption with a"
  echo "        reason, or confirm it by hand."
fi
rm -rf "$WORK"
exit $fail
